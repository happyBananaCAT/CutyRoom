const express = require("express")
const {db,genid} = require("../database/mysql")
const router = express.Router()



module.exports = router